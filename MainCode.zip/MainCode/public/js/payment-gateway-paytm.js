"use strict";
window.onload = function(){
document.forms[0].submit();
}