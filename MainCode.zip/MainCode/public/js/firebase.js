"use strict";
// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
   var firebaseConfig = {
    apiKey: "AIzaSyCGgRAIPgs7Y3V5l65bM0Zs7X3Iz1o9I5U",
    authDomain: "ecart-multi-vendor.firebaseapp.com",
    projectId: "ecart-multi-vendor",
    storageBucket: "ecart-multi-vendor.appspot.com",
    messagingSenderId: "354159859877",
    appId: "1:354159859877:web:4ac003e461ca7b5679154c",
    measurementId: "G-307XN7WR1L"
  };
// Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();