{{__('msg.hello,dear')}} {{ $name }}

{{__('msg.message')}} : {{ $msg }}

{{__('msg.phone')}} : {{ $phone }}
    
{{__('msg.thank_you')}}